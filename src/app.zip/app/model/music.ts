export class _Music{
    id:number;
    name:string;
    asrc:string;
    isrc:string;
    ogg:string;
    rating:number;
}
export interface _music{
    id:number;
    name:string;
    asrc:string;
    isrc:string;
    ogg:string;
    rating:number;
}